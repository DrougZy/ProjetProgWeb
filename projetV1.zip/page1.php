<?php 
    echo "page de tom";
    echo 
        '
            <button type="button" class="btn btn-danger" onclick="logBout()">Se déconnecter</button>
            <h1> Bienvenue </h1>
            </br> <h2> a mettre ici le code fourni par tom sur la page principale </h2>

            </br><button type="button" class="btn btn-success" onclick="loadPeopleResearch()">Rechercher quelqu\'un</button>
         ';
?>