function validateLogs()
{
  //Fonction appelée lors de la vérification de la connexion par l'utilisateur
    var var1 = $("#exampleInputEmail1").val();
    var var2 = $("#exampleInputPassword1").val();
    $.ajax( {
        type : "POST",
        url: "validateLogs.php",
        data:{"log": var1 , "pw" :var2}
      })
      .done(function(msg) {
        $("#connexionToken").html(
          "Connecté en tant que : "+ var1
        )
        $("#logs").html("<br>"+msg);
      })
      .fail(function() {
        alert( "error" );
      });
}

function loadSignPage()
{
    $.ajax( {
        url: "signUp.php",
      })
      .done(function(msg) {
        $("#contents").html(msg);
      })
      .fail(function() {
        alert( "error" );
      });
}

function loadConnectPage()
{
    $.ajax( {
        url: "connect.php",
      })
      .done(function(msg) {
        $("#contents").html(msg);
      })
      .fail(function() {
        alert( "error" );
      });   
}

function loadIndexPage(connected = false)
{
  if(connected)
  {
    $.ajax( {
    url: "page1.php",
  })
  .done(function(msg) {
    $("#contents").html(msg);
  })
  .fail(function() {
    alert( "error" );
  });  

  }
  else {
    $.ajax( {
      type : "POST",
      url: "IndexPage.php",
      data : {disconnected : true}
    })
    .done(function(msg) {
      $("#contents").html(msg);
      $("#connexionToken").html("Non connecté ");
    })
    .fail(function() {
      alert( "error" );
    });  
  } 
}

function newSubscriber()
{
    var var1 = $("#usernameSign").val();
    var var2 = $("#passwordSign").val();
    var var3 = $("#passwordSign2").val();   
    $.ajax( {
        url: "newSubscriber.php",
        type : "POST",
        data : {username : var1 , mdp1 : var2 , mdp2 : var3}
      })
      .done(function(msg) {
        $("#contents").html(msg);
          $.ajax( {
            url: "connect.php",
            type : "POST",
            data : {username : var1 , mdp1 : var2 , mdp2 : var3}
          })
          .done(function(msg) {
            $("#contents").html(msg);
          })
          .fail(function() {
            alert( "error" );
          });   
      })
      .fail(function() {
        alert( "error" );
      }); 
}

function logBout()
{
  console.log("salut");

  loadIndexPage(false);
  $("#connexionToken").html("Viens d'être déconnecté "); 
}

function loadPeopleResearch()
{
  $.ajax( {
    url: "peopleResearch.php",
    type : "POST"
    //data:{"name": $("#name").val()}
  })
  .done(function(msg) {
    $("#contents").html(msg);
  })
  .fail(function() {
    alert( "error" );
  }); 
}


function assignUserToVote()
{
  $.ajax( {
    type : "POST",
    url: "peopleResearch.php",
    data:{stringSearched: $("#searchUsers").val()}
  })
  .done(function(msg) {
    $("#contents").html(msg);
    //console.log(msg);
  })
  
}